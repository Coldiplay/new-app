[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Belp")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Belp.Pages")]

﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Belp
{
    public partial class MainPage : ContentPage, INotifyPropertyChanged
    {
        private string entryString;
        private string upperString;
        private string result = "0";
        private decimal number1;
        private decimal number2;
        private string znak;

        public MainPage()
        {
            InitializeComponent();
            BindingContext = this;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        void Signal([CallerMemberName] string prop = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));

        public string UpperString
        {
            get => upperString;
            set
            {
                upperString = value;
                Signal();
            }
        }
        public string EntryString
        {
            get => entryString;
            set
            {
                entryString = value;
                Signal();
            }
        }

        public string Result
        {
            get => result;
            set
            {
                result = value;
                Signal();
            }
        }
        public decimal Number1
        {
            get => number1;
            set
            {
                number1 = value;
                Signal();
            }
        }


        public decimal Number2
        {
            get => number2;
            set
            {
                number2 = value;
                Signal();
            }
        }
        public string Znak
        {
            get => znak;
            set
            {
                znak = value;
                Signal();
            }
        }
        Operation OperationNow { get; set; }


        private void AddNum(object sender, EventArgs e)
        {
            //for (int i = 0; i<
            if (Result == "0")
                Result = string.Empty;

            EntryString = EntryString + (sender as Button).Text;
            Result += (sender as Button).Text;


        }

        private void DoOperation(object sender, EventArgs e)
        {
            Number2 = decimal.Parse(EntryString);
            switch (Znak)
            {
                case "+":
                    Number1 = Number1 + Number2;

                    break;
                case "-":
                    Number1 = Number1 - Number2;
                    break;
                case "*":
                    Number1 = Number1 * Number2;
                    break;
                case "./.":
                    Number1 = Number1 / Number2;
                    break;
                case "1/x":
                    Number1 = 1/Number1;
                    break;
            }
            Result = $"{Number1}";
        }

        enum Operation
        {
            Add,
            Divide,
            Minus,
            Multiply,
            Square,
            SquareRoot,
            Fraction
        }

        private void AddOperation(object sender, EventArgs e)
        {
            Number1 = decimal.Parse(EntryString);
            Znak = (sender as Button).Text;
            //else if (Znak == "CE")
            //    Result = "";
        }


        private void XtoOne(object sender, EventArgs e)
        {
            Number1 = decimal.Parse(EntryString);
            Znak = "1/x";
            DoOperation(sender, e);
        }
    }

}
